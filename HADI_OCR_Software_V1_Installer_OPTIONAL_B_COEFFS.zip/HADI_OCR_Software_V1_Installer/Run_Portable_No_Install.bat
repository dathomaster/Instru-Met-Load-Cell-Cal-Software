@echo off
setlocal EnableExtensions
title HADI OCR Software V1 Portable Launcher

set "APP_DIR=%~dp0app\hadi_ocr_software"
cd /d "%APP_DIR%"

set "PYEXE="
py -3 --version >nul 2>&1
if %errorlevel%==0 (
    set "PYEXE=py -3"
) else (
    python --version >nul 2>&1
    if %errorlevel%==0 (
        set "PYEXE=python"
    )
)

if "%PYEXE%"=="" (
    echo Python was not found.
    echo Install Python 3 and check "Add python.exe to PATH".
    start https://www.python.org/downloads/windows/
    pause
    exit /b 1
)

%PYEXE% -m pip install --user pyserial >nul 2>&1
%PYEXE% "%APP_DIR%\hadi_ocr_app.py"
pause
endlocal
