@echo off
setlocal
cd /d "%~dp0"
if not exist "app\hadi_ocr_software\hadi_ocr_app.py" (
    echo ERROR: app files are missing.
    echo.
    echo Make sure you EXTRACTED the zip first.
    echo Do not run this directly from inside the zip preview.
    echo.
    pause
    exit /b 1
)
call "%~dp0Install_HADI_OCR_Software_V1.cmd"
endlocal
