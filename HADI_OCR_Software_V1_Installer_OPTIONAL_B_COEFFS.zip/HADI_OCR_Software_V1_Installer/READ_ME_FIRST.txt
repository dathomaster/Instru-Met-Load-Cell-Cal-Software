HADI OCR Software V1 - Simple Windows Install

Fast install:
1. Unzip this folder.
2. Double-click Install_HADI_OCR_Software_V1.bat.
3. Use the desktop shortcut named HADI OCR Software V1.

No admin rights are required.

If Python is not installed:
- The installer opens the Python download page.
- Install Python 3.
- During install, check "Add python.exe to PATH".
- Then run Install_HADI_OCR_Software_V1.bat again.

Where it installs:
%LOCALAPPDATA%\HADI OCR Software

Autosaves:
%LOCALAPPDATA%\HADI OCR Software\autosaves

Portable option:
Double-click Run_Portable_No_Install.bat if you want to run from this folder without installing.

Uninstall:
Double-click Uninstall_HADI_OCR_Software_V1.bat.
Copy autosaves somewhere safe first if you need them.


Shortcut fix:
If the app installed but no desktop shortcut appears, double-click:
Repair_Desktop_Shortcut.bat

You can also launch directly from:
%LOCALAPPDATA%\HADI OCR Software\Run HADI OCR Software.bat


No command prompt:
This installer uses a no-console launcher:
%LOCALAPPDATA%\HADI OCR Software\Launch HADI OCR Software.vbs

The desktop shortcut points to that VBS launcher.

If the shortcut still opens a command prompt, run:
Repair_Desktop_Shortcut.bat

For debugging only, the installer also creates:
%LOCALAPPDATA%\HADI OCR Software\Run HADI OCR Software - Console.bat


More reliable install option:
If double-clicking the .bat acts strange, use:
START_HERE_INSTALL.cmd

This creates a log on the Desktop:
HADI_OCR_Install_Log.txt

Common issue:
Make sure the zip is fully extracted first. Do not run the installer from inside the Windows zip preview.


This installer includes the B4/B5 equation fix and exact OCR packet capture fix.


This installer includes the W-row OCR-only capture fix:
- W rows can be captured without HADI connected.
- Capture preserves the HADI/weight value and only fills OCR.
- Capture advances through W rows that still need OCR.


This installer includes the W-row edit fix:
- Editing a HADI cell on an existing W row keeps W on.
- The typed value is treated as the new nominal weight and converted to local LBF.
- Existing OCR and percent error update correctly.


This installer includes GPS altitude support:
- GPS packets can include altitude as a fifth field.
- MF now uses latitude plus altitude when altitude is available.
- Missing altitude falls back to 0 m elevation.


This installer includes ASTM Table 1 MF support:
- MF is calculated from the ASTM table using latitude and elevation.
- The app interpolates between table rows/columns.
- Missing altitude falls back to 0 m.


This installer includes optional B coefficients:
- B0 through B5 can be left blank.
- Blank coefficients are treated as zero.
- The equation still uses all six B terms.
