@echo off
setlocal EnableExtensions
title Repair HADI OCR Software Shortcut

set "INSTALL_DIR=%LOCALAPPDATA%\HADI OCR Software"
set "LAUNCHER=%INSTALL_DIR%\Launch HADI OCR Software.vbs"

echo.
echo ============================================
echo   Repair HADI OCR Software V1 Shortcut
echo ============================================
echo.

if not exist "%LAUNCHER%" (
    echo Creating no-console launcher...
    set "PYWEXE=pyw -3"
    (
    echo Set WshShell = CreateObject^("WScript.Shell"^)
    echo WshShell.CurrentDirectory = "%INSTALL_DIR%"
    echo WshShell.Run "pyw -3 ""%INSTALL_DIR%\hadi_ocr_app.py""", 0, False
    ) > "%LAUNCHER%"
)

if not exist "%INSTALL_DIR%\hadi_ocr_app.py" (
    echo Could not find installed app:
    echo   %INSTALL_DIR%\hadi_ocr_app.py
    echo.
    echo Run Install_HADI_OCR_Software_V1.bat first.
    pause
    exit /b 1
)

set "DESKTOP_LINK=%USERPROFILE%\Desktop\HADI OCR Software V1.lnk"
set "VBS_FILE=%TEMP%\hadi_ocr_create_shortcut.vbs"

> "%VBS_FILE%" echo Set WshShell = WScript.CreateObject("WScript.Shell")
>> "%VBS_FILE%" echo Set Shortcut = WshShell.CreateShortcut("%DESKTOP_LINK%")
>> "%VBS_FILE%" echo Shortcut.TargetPath = "%LAUNCHER%"
>> "%VBS_FILE%" echo Shortcut.WorkingDirectory = "%INSTALL_DIR%"
>> "%VBS_FILE%" echo Shortcut.IconLocation = "shell32.dll,13"
>> "%VBS_FILE%" echo Shortcut.Save

cscript //nologo "%VBS_FILE%" >nul 2>&1
del "%VBS_FILE%" >nul 2>&1

if exist "%DESKTOP_LINK%" (
    echo Desktop shortcut created:
    echo   %DESKTOP_LINK%
    echo.
    echo It should now launch without a command prompt.
) else (
    echo Shortcut failed.
    echo You can launch directly from:
    echo   %LAUNCHER%
)

echo.
pause
endlocal
