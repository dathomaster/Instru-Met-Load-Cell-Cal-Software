@echo off
setlocal EnableExtensions
title HADI OCR Software V1 Uninstaller

set "INSTALL_DIR=%LOCALAPPDATA%\HADI OCR Software"
set "START_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\HADI OCR Software"

echo.
echo ============================================
echo   HADI OCR Software V1 Uninstaller
echo ============================================
echo.
echo This will remove the installed app folder:
echo   %INSTALL_DIR%
echo.
echo NOTE: This also removes autosaves inside that folder.
echo Copy autosaves somewhere else first if you need them.
echo.
choice /M "Continue uninstall"
if errorlevel 2 exit /b 0

if exist "%USERPROFILE%\Desktop\HADI OCR Software V1.lnk" del "%USERPROFILE%\Desktop\HADI OCR Software V1.lnk"
if exist "%START_DIR%" rmdir /S /Q "%START_DIR%"
if exist "%INSTALL_DIR%" rmdir /S /Q "%INSTALL_DIR%"

echo.
echo Uninstalled.
pause
endlocal
