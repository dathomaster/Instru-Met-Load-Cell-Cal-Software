@echo off
setlocal EnableExtensions EnableDelayedExpansion

title HADI OCR Software V1 Installer

echo.
echo ============================================
echo   HADI OCR Software V1 Installer
echo ============================================
echo.
echo This installer does not need admin rights.
echo It will install to:
echo   %LOCALAPPDATA%\HADI OCR Software
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\HADI OCR Software"
set "SOURCE_DIR=%~dp0app\hadi_ocr_software"

if not exist "%SOURCE_DIR%\hadi_ocr_app.py" (
    echo ERROR: Could not find app files.
    echo Expected:
    echo   %SOURCE_DIR%\hadi_ocr_app.py
    echo.
    pause
    exit /b 1
)

echo Checking for Python...
set "PYEXE="
set "PYWEXE="

py -3 --version >nul 2>&1
if %errorlevel%==0 (
    set "PYEXE=py -3"
    set "PYWEXE=pyw -3"
) else (
    python --version >nul 2>&1
    if %errorlevel%==0 (
        set "PYEXE=python"
        set "PYWEXE=pythonw"
    )
)

if "%PYEXE%"=="" (
    echo.
    echo Python was not found on this computer.
    echo.
    echo Please install Python 3 from:
    echo   https://www.python.org/downloads/windows/
    echo.
    echo IMPORTANT: During Python install, check:
    echo   Add python.exe to PATH
    echo.
    start https://www.python.org/downloads/windows/
    pause
    exit /b 1
)

echo Found Python using: %PYEXE%
echo.

echo Creating install folder...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%\autosaves" mkdir "%INSTALL_DIR%\autosaves"

echo Copying app files...
xcopy "%SOURCE_DIR%\*" "%INSTALL_DIR%\" /E /I /Y >nul
if errorlevel 1 (
    echo ERROR: File copy failed.
    pause
    exit /b 1
)

echo.
echo Installing Python dependencies...
%PYEXE% -m pip install --user pyserial > "%INSTALL_DIR%\install_log.txt" 2>&1
if errorlevel 1 (
    echo WARNING: pyserial install may have failed.
    echo See:
    echo   %INSTALL_DIR%\install_log.txt
    echo.
    echo The app may still launch, but HADI COM connection needs pyserial.
    echo.
) else (
    echo Dependencies installed.
)

echo.
echo Creating no-console launcher...
(
echo Set WshShell = CreateObject^("WScript.Shell"^)
echo WshShell.CurrentDirectory = "%INSTALL_DIR%"
echo WshShell.Run "%PYWEXE% ""%INSTALL_DIR%\hadi_ocr_app.py""", 0, False
) > "%INSTALL_DIR%\Launch HADI OCR Software.vbs"

echo Creating backup console launcher...
(
echo @echo off
echo cd /d "%INSTALL_DIR%"
echo %PYEXE% "%INSTALL_DIR%\hadi_ocr_app.py"
echo pause
) > "%INSTALL_DIR%\Run HADI OCR Software - Console.bat"

echo Creating desktop shortcut...
set "DESKTOP_LINK=%USERPROFILE%\Desktop\HADI OCR Software V1.lnk"
set "VBS_FILE=%TEMP%\hadi_ocr_create_shortcut.vbs"

> "%VBS_FILE%" echo Set WshShell = WScript.CreateObject("WScript.Shell")
>> "%VBS_FILE%" echo Set Shortcut = WshShell.CreateShortcut("%DESKTOP_LINK%")
>> "%VBS_FILE%" echo Shortcut.TargetPath = "%INSTALL_DIR%\Launch HADI OCR Software.vbs"
>> "%VBS_FILE%" echo Shortcut.WorkingDirectory = "%INSTALL_DIR%"
>> "%VBS_FILE%" echo Shortcut.IconLocation = "shell32.dll,13"
>> "%VBS_FILE%" echo Shortcut.Save

cscript //nologo "%VBS_FILE%" >nul 2>&1
if exist "%DESKTOP_LINK%" (
    echo Desktop shortcut created.
) else (
    echo WARNING: Desktop shortcut was not created.
    echo You can still launch from:
    echo   %INSTALL_DIR%\Launch HADI OCR Software.vbs
)

echo Creating Start Menu shortcut...
set "START_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\HADI OCR Software"
if not exist "%START_DIR%" mkdir "%START_DIR%"
set "START_LINK=%START_DIR%\HADI OCR Software V1.lnk"

> "%VBS_FILE%" echo Set WshShell = WScript.CreateObject("WScript.Shell")
>> "%VBS_FILE%" echo Set Shortcut = WshShell.CreateShortcut("%START_LINK%")
>> "%VBS_FILE%" echo Shortcut.TargetPath = "%INSTALL_DIR%\Launch HADI OCR Software.vbs"
>> "%VBS_FILE%" echo Shortcut.WorkingDirectory = "%INSTALL_DIR%"
>> "%VBS_FILE%" echo Shortcut.IconLocation = "shell32.dll,13"
>> "%VBS_FILE%" echo Shortcut.Save

cscript //nologo "%VBS_FILE%" >nul 2>&1
del "%VBS_FILE%" >nul 2>&1

if exist "%START_LINK%" (
    echo Start Menu shortcut created.
) else (
    echo WARNING: Start Menu shortcut was not created.
)

echo.
echo ============================================
echo   Installed successfully.
echo ============================================
echo.
echo You can launch it with no command prompt from:
echo   Desktop shortcut: HADI OCR Software V1
echo or:
echo   %INSTALL_DIR%\Launch HADI OCR Software.vbs
echo.
echo If you need to see errors/debug logs, use:
echo   %INSTALL_DIR%\Run HADI OCR Software - Console.bat
echo.
echo Autosaves will be kept in:
echo   %INSTALL_DIR%\autosaves
echo.
choice /M "Launch HADI OCR Software now"
if errorlevel 2 goto end
wscript "%INSTALL_DIR%\Launch HADI OCR Software.vbs"

:end
echo.
pause
endlocal
